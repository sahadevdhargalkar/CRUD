import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SharedServiceService {
id!:Number;
  constructor() { }
  setId(idNumber:number){
    this.id=idNumber;
  }
  getId(){
    return this.id;
  }
}
