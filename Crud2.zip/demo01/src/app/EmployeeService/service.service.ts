import { Injectable } from '@angular/core';
 import { HttpClient, HttpHeaders } from '@angular/common/http';
import { EmployeeClass } from '../models/employee-class';

const httpOptions = {
  headers:new HttpHeaders({
    'Content-Type':'application/json',
    'observe':'response'
  })
}

 @Injectable({
  providedIn: 'root'
})
export class ServiceService {


  constructor(private http:HttpClient) { }

  getAllEmployees(){
    return this.http.get("http://localhost:8080/api/getData",httpOptions);
    
  }
  addNewEmployee(newEmp:EmployeeClass){
     return this.http.post("http://localhost:8080/api/addEmp",newEmp,httpOptions);
  }
  deleteEmployee(id:Number){
    return this.http.delete("http://localhost:8080/api/deleteEmp/"+id,httpOptions);
  }
  getEmpById(id1:any){
    return this.http.get("http://localhost:8080/api/getEmpById/"+id1,httpOptions);
  }
  updateEmployee(id:number,editedEmp:EmployeeClass){
    return this.http.put("http://localhost:8080/api/editEmp/"+id,editedEmp,httpOptions);
  }
}
