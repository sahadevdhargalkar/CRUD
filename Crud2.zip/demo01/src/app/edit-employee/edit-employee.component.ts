import { Component, OnInit } from '@angular/core';
import { EmployeeClass } from '../models/employee-class';
import { SharedServiceService } from '../EmployeeService/shared-service.service';
import { ServiceService } from '../EmployeeService/service.service';
import { Route } from '@angular/router';

@Component({
  selector: 'app-edit-employee',
  templateUrl: './edit-employee.component.html',
  styleUrls: ['./edit-employee.component.css']
})
export class EditEmployeeComponent implements OnInit {
 editEmp:any=new EmployeeClass();
 empId!:Number;
 updatedEmp:EmployeeClass = new EmployeeClass();
  constructor(private shared:SharedServiceService,private empService:ServiceService) { }

  ngOnInit(): void {
    this.empId=this.shared.getId();
    console.log(this.empId,"getid");
    this.empService.getEmpById(this.empId).subscribe(data =>{
      this.editEmp=data;
      console.log(this.editEmp,"getDAta");
    });
  }
  editEmployee(){
    console.log(this.updatedEmp);
  }

}
