export class EmployeeClass {
 
  name!:String  ;
  email!:String ;
  constructor(){}
  
} 
