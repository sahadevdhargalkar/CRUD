import { EmployeeClass } from './employee-class';

describe('EmployeeClass', () => {
  it('should create an instance', () => {
    expect(new EmployeeClass()).toBeTruthy();
  });
});
