import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from '../EmployeeService/service.service';
import { EmployeeClass } from '../models/employee-class';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  newEmp = new EmployeeClass();
  constructor(private EmpService:ServiceService,private route:Router) { }

  ngOnInit(): void {
  }

addEmployee(){
   console.log(this.newEmp);
   this.EmpService.addNewEmployee(this.newEmp).subscribe(data=>{
     console.log("Response",data);
   })
   this.route.navigate(["/employees"]);
}

}
