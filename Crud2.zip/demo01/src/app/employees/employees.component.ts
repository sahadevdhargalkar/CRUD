import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from '../EmployeeService/service.service';
import { SharedServiceService } from '../EmployeeService/shared-service.service';
declare var window:any;
@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {
 allEmployees: any;
 formModal:any;
 formModal1:any;
 Name!:String;
 EmpId!:String;
 EmpId2!:String;
 Email!:String;

 
  constructor(private empService: ServiceService,private route:Router,private shared:SharedServiceService) { }

  ngOnInit(): void {
  this.empService.getAllEmployees().subscribe(items => {
    this.allEmployees = items
    console.log("items",this.allEmployees);
  })

    
  }
  openModal(id:any,email:any,name:any){
    this.formModal = new window.bootstrap.Modal(
      document.getElementById("exampleModal")
    );
    this.EmpId=id;
    this.Email=email;
    this.Name=name;
    this.formModal.show();
  }
  openIdModal(id:any){
    this.formModal1 = new window.bootstrap.Modal(
      document.getElementById("IdModal")
    );
    this.EmpId=id;
    this.formModal1.show();
  }
  closeModal(){
    this.formModal.hide();
  }
  goToAddEmp(){
    this.route.navigate(["/addEmployee"]);
    
  }
  deleteEmployee(id:any){
    console.log(id);
    if(window.confirm("Delete Employee?")){
           this.empService.deleteEmployee(id).subscribe(data =>{
            console.log(data);
           })
         //  window.location.reload();
    }
 }
 goToEdit(id:any){
  this.shared.setId(id);
  this.route.navigate(["/editEmployee/"+id]);
}

}
